#!/usr/bin/env python3
"""Export the tutorial ball's mesh for the Godot presentation section.

A face-varying ``st`` primvar and a bound UsdPreviewSurface still take the
OpenSubdiv path. The striped stage has neither: vertex ``displayColor`` is
painted into a PNG, corners get spherical UVs, and each control point gets
a cage stencil. The Godot player still reads a UsdPreviewSurface PNG; the
stage does not have to author one.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import base64
import struct
import zlib

PLUGIN = Path(__file__).resolve().parents[1]
USD = PLUGIN.parent / "usd-install"
RIG = PLUGIN.parent / "usdRig"
DLL_HANDLES = []


def _bootstrap_usd():
    if os.name == "nt":
        for folder in (USD / "bin", USD / "lib"):
            if folder.is_dir():
                DLL_HANDLES.append(os.add_dll_directory(str(folder)))
    for folder in (USD / "Lib/site-packages", USD / "lib/python"):
        if folder.exists():
            sys.path.insert(0, str(folder))
    for finder in list(sys.meta_path):
        try:
            spec = finder.find_spec("pxr", None)
        except (AttributeError, ImportError):
            continue
        if spec and str(USD).lower() not in (
                (spec.origin or "") + str(spec.submodule_search_locations)).lower():
            sys.meta_path.remove(finder)


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _scale(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def orient_outward(points, counts, indices, center=(0.0, 1.0, 0.0)):
    """Reverse faces whose first corner normal points toward the ball centre."""
    out = list(indices)
    offset = 0
    reversed_faces = 0
    center = tuple(center)
    for count in counts:
        face = out[offset:offset + count]
        a, b, c = (points[i] for i in face[:3])
        normal = _cross(_sub(b, a), _sub(c, a))
        mid = _scale(_add(_add(a, b), c), 1.0 / 3.0)
        if _dot(normal, _sub(mid, center)) < 0:
            out[offset:offset + count] = list(reversed(face))
            reversed_faces += 1
        offset += count
    return out, reversed_faces


def _png(width, height, rgb):
    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data +
                struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))
    raw = b"".join(b"\x00" + bytes(rgb[y * width * 3:(y + 1) * width * 3])
                   for y in range(height))
    return (b"\x89PNG\r\n\x1a\n" +
            chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(raw, 9)) +
            chunk(b"IEND", b""))


def stripe_png(points, colors, width=128, height=64):
    """Latitude rows sampled from vertex displayColor. The equator stays centred."""
    ys = [p[1] for p in points]
    ymin, ymax = min(ys), max(ys)
    span = max(ymax - ymin, 1e-6)
    rgb = bytearray(width * height * 3)
    for row in range(height):
        y = ymin + (row + 0.5) / height * span
        band = span / height
        chosen = [colors[i] for i, p in enumerate(points) if abs(p[1] - y) <= band]
        if not chosen:
            i = min(range(len(points)), key=lambda k: abs(points[k][1] - y))
            chosen = [colors[i]]
        col = tuple(int(max(0, min(255, round(sum(c[k] for c in chosen) /
                                              len(chosen) * 255))))
                    for k in range(3))
        for x in range(width):
            o = (row * width + x) * 3
            rgb[o:o + 3] = bytes(col)
    return _png(width, height, rgb)


def display_color_presentation(points, counts, indices, colors, controls,
                               points_path, prim_path):
    """Cage mesh, spherical UVs and a stripe PNG. No authored st or material."""
    if len(colors) == 1:
        colors = list(colors) * len(points)
    if len(colors) != len(points):
        raise SystemExit(
            f"displayColor has {len(colors)} values for {len(points)} points")
    indices, reversed_faces = orient_outward(points, counts, indices)
    center = (0.0, 1.0, 0.0)
    incident = [None] * len(points)
    offset = 0
    for count in counts:
        face = indices[offset:offset + count]
        for k, index in enumerate(face):
            if incident[index] is None:
                incident[index] = (face[(k - 1) % count], face[(k + 1) % count])
        offset += count
    stencils = []
    for i, (prev, nxt) in enumerate(incident):
        if prev is None:
            raise SystemExit(f"point {i} is not in a face")
        du = _sub(points[nxt], points[i])
        dv = _sub(points[prev], points[i])
        if _dot(_cross(du, dv), _sub(points[i], center)) < 0:
            prev, nxt = nxt, prev
        stencils.append([[i, 1.0], [nxt, 1.0, i, -1.0], [prev, 1.0, i, -1.0]])
    ys = [p[1] for p in points]
    ymin, ymax = min(ys), max(ys)
    span = max(ymax - ymin, 1e-6)
    corner_uv = []
    offset = 0
    for count in counts:
        face = indices[offset:offset + count]
        us = []
        for index in face:
            x, y, z = points[index]
            us.append(math.atan2(z, x) / (2.0 * math.pi) + 0.5)
        if max(us) - min(us) > 0.5:
            us = [u + 1.0 if u < 0.5 else u for u in us]
        for index, u in zip(face, us):
            v = (points[index][1] - ymin) / span
            corner_uv.append((u, v))
        offset += count
    render_vertices, render_uvs = [], []
    offset = 0
    corner = 0
    for count in counts:
        face_uv = corner_uv[corner:corner + count]
        for j in range(1, count - 1):
            for slot in (0, j + 1, j):
                render_vertices.append(indices[offset + slot])
                render_uvs.extend(face_uv[slot])
        offset += count
        corner += count
    png = stripe_png(points, colors)
    diffuse = [1.0, 1.0, 1.0]
    emission = [0.0, 0.0, 0.0]
    params = dict(metallic=0.0, roughness=0.5, specular=0.35)
    manifest = dict(
        source="usdRig/docs/examples/tutorial_rolling_ball_free.usda",
        prim=prim_path, material="", points=len(points), faces=len(counts),
        corners=len(indices), uv_interpolation="displayColor-spherical",
        outward_winding_corrected_faces=reversed_faces,
        fvar_rule="", subdivision="control cage",
        texture_sha256=hashlib.sha256(png).hexdigest(),
        diffuse_scale=diffuse + [1.0], emission_scale=emission + [1.0], **params)
    mesh = dict(
        path=prim_path, points_path=points_path, source_point_count=len(points),
        stencils=stencils, vertex_indices=render_vertices, uvs=render_uvs,
        material=dict(model="UsdPreviewSurface",
                      texture_png=base64.b64encode(png).decode("ascii"),
                      diffuse_scale=diffuse, emission_scale=emission,
                      wrap_s="repeat", wrap_t="clamp", **params))
    return dict(version=1, controls=controls, meshes=[mesh], source=manifest)


def append_presentation(target, presentation):
    data = Path(target).read_bytes()
    magic, version, count, flags = struct.unpack_from("<4sIII", data)
    if magic != b"REXB" or version & 65535 != 1:
        raise SystemExit(f"{target} is not a REXB v1 program")
    sections = []
    for i in range(count):
        tag, offset, size = struct.unpack_from("<IQQ", data, 16 + i * 20)
        if tag != 13:
            sections.append((tag, data[offset:offset + size]))
    sections.append((13, json.dumps(presentation, separators=(",", ":"),
                                    allow_nan=False).encode("utf-8")))
    offset = 16 + len(sections) * 20
    table = bytearray()
    payloads = []
    for tag, payload in sections:
        table.extend(struct.pack("<IQQ", tag, offset, len(payload)))
        payloads.append(payload)
        offset += len(payload)
    result = (struct.pack("<4sIII", magic, version, len(sections), flags) +
              table + b"".join(payloads))
    Path(target).write_bytes(result)


def _controls_from_stage(stage):
    from pxr import Usd
    controls = []
    for prim in stage.Traverse():
        exposed = prim.GetAttribute("rigExec:exposedAvars").Get()
        if not exposed:
            continue
        if str(prim.GetTypeName()) != "RigExecControl":
            raise SystemExit(f"{prim.GetPath()} exposes avars but is not a control")
        public = prim.GetAttribute("rigExec:publicName").Get() or prim.GetName()
        for channel in exposed:
            if channel not in ("tx", "ty", "tz", "rx", "ry", "rz", "sx", "sy", "sz"):
                raise SystemExit(f"unsupported exposed avar {channel}")
            attr = prim.GetAttribute("avars:" + channel)
            controls.append(dict(
                name=public + "." + channel, path=str(attr.GetPath()),
                default=attr.Get(Usd.TimeCode(1001)),
                unit="degrees" if channel.startswith("r") else
                "asset_units" if channel.startswith("t") else "ratio"))
    if not controls or len({c["name"] for c in controls}) != len(controls):
        raise SystemExit("public control names are missing or duplicated")
    return controls


def _export_textured(stage, mesh):
    from pxr import Gf, UsdGeom, UsdShade
    if mesh.GetSubdivisionSchemeAttr().Get() != "catmullClark":
        raise SystemExit("textured export expects catmullClark")
    if mesh.GetOrientationAttr().Get() != "rightHanded":
        raise SystemExit("textured export expects rightHanded")
    if mesh.GetCreaseIndicesAttr().Get() or mesh.GetHoleIndicesAttr().Get():
        raise SystemExit("textured export does not support creases or holes")
    st = UsdGeom.PrimvarsAPI(mesh).GetPrimvar("st")
    if not st or st.GetInterpolation() != "faceVarying":
        return None
    material, _ = UsdShade.MaterialBindingAPI(mesh).ComputeBoundMaterial()
    if not material:
        return None
    points = mesh.GetPointsAttr().Get()
    counts = list(mesh.GetFaceVertexCountsAttr().Get())
    indices = list(mesh.GetFaceVertexIndicesAttr().Get())
    corner_uv = st.ComputeFlattened()
    if sum(counts) != len(indices) or len(indices) != len(corner_uv):
        raise SystemExit("face-varying st does not match the face corners")
    uv = [tuple(value) for value in st.Get()]
    uv_indices = list(st.GetIndices()) if st.IsIndexed() else list(range(len(uv)))
    offset = 0
    reversed_faces = 0
    for count in counts:
        face = indices[offset:offset + count]
        a, b, c = (points[i] for i in face[:3])
        if Gf.Dot(Gf.Cross(b - a, c - a), (a + b + c) / 3 - Gf.Vec3f(0, 1, 0)) < 0:
            indices[offset:offset + count] = reversed(face)
            uv_indices[offset:offset + count] = reversed(uv_indices[offset:offset + count])
            reversed_faces += 1
        offset += count
    rule = mesh.GetPrim().GetAttribute("faceVaryingLinearInterpolation").Get()
    rules = ["none", "cornersOnly", "cornersPlus1", "cornersPlus2", "boundaries", "all"]
    surface, _, _ = material.ComputeSurfaceSource()
    if surface.GetIdAttr().Get() != "UsdPreviewSurface":
        raise SystemExit("bound material is not UsdPreviewSurface")
    inputs = {}
    for name in ("diffuseColor", "emissiveColor"):
        source, _, _ = surface.GetInput(name).GetConnectedSource()
        shader = UsdShade.Shader(source.GetPrim())
        if shader.GetIdAttr().Get() != "UsdUVTexture":
            raise SystemExit(f"{name} is not a UsdUVTexture")
        reader, _, _ = shader.GetInput("st").GetConnectedSource()
        if UsdShade.Shader(reader.GetPrim()).GetInput("varname").Get() != "st":
            raise SystemExit("texture st reader is not the st primvar")
        if shader.GetInput("wrapS").Get() != "repeat" or shader.GetInput("wrapT").Get() != "clamp":
            raise SystemExit("texture wrap must be repeat S and clamp T")
        asset = shader.GetInput("file").Get()
        inputs[name] = dict(texture=asset.resolvedPath, scale=list(shader.GetInput("scale").Get()))
    if inputs["diffuseColor"]["texture"] != inputs["emissiveColor"]["texture"]:
        raise SystemExit("diffuse and emissive textures differ")
    assets = PLUGIN / "build/rolling_ball"
    assets.mkdir(parents=True, exist_ok=True)
    source_mesh = assets / "tutorial_ball.control_mesh.txt"
    with source_mesh.open("w") as stream:
        stream.write(f"{len(points)} {len(counts)} {len(uv)} {rules.index(rule)}\n")
        for p in points:
            stream.write(" ".join(map(str, p)) + "\n")
        stream.write(" ".join(map(str, counts)) + "\n")
        stream.write(" ".join(map(str, indices)) + "\n")
        for v in uv:
            stream.write(" ".join(map(str, v)) + "\n")
        stream.write(" ".join(map(str, uv_indices)) + "\n")
    tool = PLUGIN / "tools" / ("ball_subdivide.exe" if os.name == "nt" else "ball_subdivide")
    cpp = tool.with_suffix(".cpp")
    if not tool.exists() or tool.stat().st_mtime < cpp.stat().st_mtime:
        if os.name == "nt":
            subprocess.run([str(PLUGIN / "tools/build_ball_subdivide.bat")], check=True)
        else:
            subprocess.run(["c++", "-std=c++17", "-O2", str(cpp), "-I" + str(USD / "include"),
                            "-L" + str(USD / "lib"), "-losdCPU", "-o", str(tool)], check=True)
    subprocess.run([str(tool), str(source_mesh), str(assets / "tutorial_ball.obj"),
                    str(assets / "tutorial_ball.stencils.json")], check=True)
    texture = Path(inputs["diffuseColor"]["texture"])
    shutil.copy2(texture, assets / texture.name)
    params = {name: surface.GetInput(name).Get() for name in ("metallic", "roughness", "specular")}
    diffuse = inputs["diffuseColor"]["scale"]
    emission = inputs["emissiveColor"]["scale"]
    manifest = dict(source="usdRig/docs/examples/tutorial_rolling_ball_free.usda",
                    prim=str(mesh.GetPath()), material=str(material.GetPath()),
                    points=len(points), faces=len(counts), corners=len(indices),
                    uv_interpolation=str(st.GetInterpolation()),
                    outward_winding_corrected_faces=reversed_faces, fvar_rule=rule,
                    subdivision="OpenSubdiv Catmull-Clark, level 2, limit surface",
                    texture_sha256=hashlib.sha256(texture.read_bytes()).hexdigest(),
                    diffuse_scale=diffuse, emission_scale=emission, **params)
    vertices, texcoords, faces = [], [], []
    for line in (assets / "tutorial_ball.obj").read_text().splitlines():
        fields = line.split()
        if not fields:
            continue
        if fields[0] == "v":
            vertices.append(list(map(float, fields[1:])))
        elif fields[0] == "vt":
            texcoords.append(list(map(float, fields[1:])))
        elif fields[0] == "f":
            faces.append([tuple(int(x) - 1 for x in c.split("/")) for c in fields[1:]])
    render_vertices, render_uvs = [], []
    for face in faces:
        for j in range(1, len(face) - 1):
            for vi, ti, _ in (face[0], face[j + 1], face[j]):
                render_vertices.append(vi)
                render_uvs.extend((texcoords[ti][0], 1 - texcoords[ti][1]))
    controls = _controls_from_stage(stage)
    presentation = dict(version=1, controls=controls, meshes=[dict(
        path=str(mesh.GetPath()), points_path=str(mesh.GetPointsAttr().GetPath()),
        source_point_count=len(points),
        stencils=json.loads((assets / "tutorial_ball.stencils.json").read_text()),
        vertex_indices=render_vertices, uvs=render_uvs,
        material=dict(model="UsdPreviewSurface",
                      texture_png=base64.b64encode(texture.read_bytes()).decode("ascii"),
                      diffuse_scale=diffuse[:3], emission_scale=emission[:3],
                      wrap_s="repeat", wrap_t="clamp", **params))], source=manifest)
    return presentation


def _mesh_from_usda_text(path):
    """Read the tutorial ball's points, faces and vertex displayColor."""
    import re
    text = Path(path).read_text(encoding="utf-8")
    if "prepend references" in text.split("def Xform", 1)[-1][:400]:
        ref = re.search(r"@([^@]+)@", text)
        path = Path(path).parent / ref.group(1)
        text = path.read_text(encoding="utf-8")
    start = text.find('def Mesh "Ball"')
    end = text.find('def Mesh "Ground"', start)
    block = text[start:end]
    def array(name):
        match = re.search(re.escape(name) + r" = \[([^\]]*)\]", block)
        return re.findall(r"\(([^)]*)\)", match.group(1))
    points = [tuple(float(v) for v in item.split(",")) for item in array("point3f[] points")]
    colors = [tuple(float(v) for v in item.split(",")) for item in array("color3f[] primvars:displayColor")]
    counts = [int(v) for v in re.search(r"faceVertexCounts = \[([^\]]*)\]", block).group(1).split(",") if v.strip()]
    indices = [int(v) for v in re.search(r"faceVertexIndices = \[([^\]]*)\]", block).group(1).split(",") if v.strip()]
    return points, counts, indices, colors


def _controls_from_rexb(path):
    data = Path(path).read_bytes()
    magic, version, count, _flags = struct.unpack_from("<4sIII", data)
    if magic != b"REXB":
        raise SystemExit(f"{path} is not a REXB program")
    for i in range(count):
        tag, offset, size = struct.unpack_from("<IQQ", data, 16 + i * 20)
        if tag == 13:
            return json.loads(data[offset:offset + size])["controls"]
    raise SystemExit(f"{path} has no presentation controls to keep")


def main():
    stage_path = RIG / "docs/examples/tutorial_rolling_ball_free.usda"
    target = PLUGIN / "demo/rolling_ball.rigexec"
    if len(sys.argv) >= 3 and sys.argv[1] == "--display-color":
        stage_path = Path(sys.argv[2])
        if len(sys.argv) >= 4:
            target = Path(sys.argv[3])
        points, counts, indices, colors = _mesh_from_usda_text(stage_path)
        controls = _controls_from_rexb(target)
        presentation = display_color_presentation(
            points, counts, indices, colors, controls,
            "/BallAsset/Geom/Ball.points", "/BallAsset/Geom/Ball")
        append_presentation(target, presentation)
        print(f"Embedded displayColor cage, stripe PNG and {len(controls)} public controls in {target}")
        return
    _bootstrap_usd()
    from pxr import Usd, UsdGeom
    stage = Usd.Stage.Open(str(stage_path))
    if not stage:
        raise SystemExit(f"cannot open {stage_path}")
    mesh = UsdGeom.Mesh(stage.GetPrimAtPath("/BallAsset/Geom/Ball"))
    presentation = _export_textured(stage, mesh)
    if presentation is None:
        points = [tuple(p) for p in mesh.GetPointsAttr().Get()]
        counts = list(mesh.GetFaceVertexCountsAttr().Get())
        indices = list(mesh.GetFaceVertexIndicesAttr().Get())
        color = UsdGeom.PrimvarsAPI(mesh).GetPrimvar("displayColor")
        values = [tuple(c) for c in (color.Get() or [])]
        if color.GetInterpolation() == "constant" and values:
            values = [values[0]]
        elif color.GetInterpolation() not in ("vertex", "varying", "constant"):
            raise SystemExit(
                "striped export needs vertex displayColor, or face-varying st "
                "with a bound preview surface")
        presentation = display_color_presentation(
            points, counts, indices, values, _controls_from_stage(stage),
            str(mesh.GetPointsAttr().GetPath()), str(mesh.GetPath()))
        print(f"Embedded displayColor cage and stripe PNG for {mesh.GetPath()}")
    else:
        print(f"Embedded subdivided preview-surface mesh for {mesh.GetPath()}")
    append_presentation(target, presentation)


if __name__ == "__main__":
    main()
