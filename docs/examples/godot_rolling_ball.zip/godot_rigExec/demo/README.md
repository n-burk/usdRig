# Roll / Collect — one self-contained rigExec asset

Open project.godot in Godot 4.7+ and press F5. WASD or the arrows move,
Space hops, Shift brakes, and R resets. Collect six rings and reach the exit.

rolling_ball.tscn owns a collision body and RigExecPlayer. The player loads
rolling_ball.rigexec. That file embeds the execution program and a
presentation section (deformed-point bindings, cage stencils, UVs,
a stripe PNG, and public controller names). No Godot skeleton or loose
mesh, material, or texture files are required to play.

rolling_ball.gd drives Move.tx, Move.ty, Move.tz, Roll.rx, Roll.ry, and
Roll.rz through set_control(). evaluate() runs the rig and updates the
render mesh. reset_controls() restores the baseline. get_controls() lists
the public names and does not expose USD paths.

The free-variant wrapper in the usdRig checkout declares
rigExec:exposedAvars and rigExec:publicName on Move and Roll. The legacy
skeleton adapter remains available for older program-only files; this
example does not use it.

The presentation PNG is a latitude stripe sampled from the stage's vertex
displayColor. The player still uses its UsdPreviewSurface shader: diffuse
scale 1, emission scale 0, roughness 0.5, metallic 0, specular 0.35,
repeat on S, and clamp on T. The render mesh is the control cage. The
stage checked in at docs/examples/tutorial_rolling_ball.usda has no UVs
and no preview surface; export_ball_assets.py builds this presentation
from displayColor. Playing this project uses the baked file already here.

setup_rolling.py looks for a sibling directory named usdRig and for
usd-install. Close the Godot editor before running it. The bake command
it runs does not pass --poseable:

    rigExecBake docs/examples/tutorial_rolling_ball_free.usda --frames 1001 -o demo/rolling_ball.rigexec

Walkthrough: docs/concepts/tutorial-godot-baked-rig.md in the usdRig checkout.
Format: docs/specs/rigexec-presentation.md
